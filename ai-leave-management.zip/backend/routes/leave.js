
import express from 'express';
import LeaveRequest from '../models/LeaveRequest.js';

const router = express.Router();

router.post('/apply', async (req, res) => {
  try {
    const leave = await LeaveRequest.create(req.body);
    res.json(leave);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/all', async (req, res) => {
  const data = await LeaveRequest.find().populate('userId');
  res.json(data);
});

router.post('/update-status', async (req, res) => {
  const { id, status } = req.body;
  const data = await LeaveRequest.findByIdAndUpdate(id, { status }, { new: true });
  res.json(data);
});

export default router;

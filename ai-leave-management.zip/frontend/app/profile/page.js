"use client";
import { useEffect, useState } from "react";

export default function ProfilePage() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    department: "",
    year: "",
  });
  const [successMessage, setSuccessMessage] = useState("");

  useEffect(() => {
    // ✅ localStorage मधून student info load करा
    const savedUser = JSON.parse(localStorage.getItem("user"));
    if (savedUser) {
      setForm(savedUser);
    }
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({
      ...form,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // ✅ Update localStorage
    localStorage.setItem("user", JSON.stringify(form));

    setSuccessMessage("✅ Profile updated successfully!");
    setTimeout(() => setSuccessMessage(""), 2000);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-purple-500 to-teal-400 p-6">
      <div className="bg-white rounded-2xl shadow-lg p-8 w-full max-w-md">
        <h2 className="text-2xl font-bold text-center mb-6">My Profile</h2>

        {successMessage && (
          <div className="mb-4 p-3 rounded-lg bg-green-100 border border-green-400 text-green-700 text-sm text-center">
            {successMessage}
          </div>
        )}

        <form className="space-y-4" onSubmit={handleSubmit}>
          {/* Name */}
          <input
            type="text"
            name="name"
            value={form.name}
            onChange={handleChange}
            placeholder="Full Name"
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-400 outline-none"
            required
          />

          {/* Email */}
          <input
            type="email"
            name="email"
            value={form.email}
            onChange={handleChange}
            placeholder="Email"
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-400 outline-none"
            required
          />

          {/* Department */}
          <select
            name="department"
            value={form.department}
            onChange={handleChange}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-400 outline-none"
          >
            <option value="AI">AI</option>
            <option value="CS">CS</option>
            <option value="IT">IT</option>
          </select>

          {/* Year */}
          <select
            name="year"
            value={form.year}
            onChange={handleChange}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-400 outline-none"
          >
            <option value="I">I Year</option>
            <option value="II">II Year</option>
            <option value="III">III Year</option>
          </select>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full py-2 text-white font-semibold rounded-lg bg-gradient-to-r from-purple-500 to-teal-400 hover:opacity-90 transition"
          >
            Update Profile
          </button>
        </form>
      </div>
    </div>
  );
}

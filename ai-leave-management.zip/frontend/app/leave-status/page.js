"use client";
import { useEffect, useState } from "react";

export default function LeaveStatusPage() {
  const [leaves, setLeaves] = useState([]);

  useEffect(() => {
    // Get logged-in user
    const user = JSON.parse(localStorage.getItem("user"));

    // Get all leaves
    const savedLeaves = JSON.parse(localStorage.getItem("leaves") || "[]");

    if (user) {
      // Filter only current student's leaves
      const studentLeaves = savedLeaves.filter(
        (leave) => leave.email === user.email
      );
      setLeaves(studentLeaves);
    }
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-purple-500 to-teal-400 p-6">
      <div className="bg-white rounded-2xl shadow-lg p-8 w-full max-w-3xl">
        <h2 className="text-2xl font-bold text-center mb-6">My Leave History</h2>

        {leaves.length === 0 ? (
          <p className="text-center text-gray-600">No leave applications yet.</p>
        ) : (
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-purple-100">
                <th className="border px-4 py-2">Reason</th>
                <th className="border px-4 py-2">From</th>
                <th className="border px-4 py-2">To</th>
                <th className="border px-4 py-2">Status</th>
              </tr>
            </thead>
            <tbody>
              {leaves.map((leave, index) => (
                <tr key={index} className="text-center">
                  <td className="border px-4 py-2">{leave.reason}</td>
                  <td className="border px-4 py-2">{leave.fromDate}</td>
                  <td className="border px-4 py-2">{leave.toDate}</td>
                  <td
                    className={`border px-4 py-2 font-semibold ${
                      leave.status === "Approved"
                        ? "text-green-600"
                        : leave.status === "Rejected"
                        ? "text-red-600"
                        : "text-blue-600"
                    }`}
                  >
                    {leave.status}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

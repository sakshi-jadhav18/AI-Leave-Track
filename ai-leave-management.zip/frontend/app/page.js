"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function RegisterPage() {
  const router = useRouter();

  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    department: "AI",
    year: "I",
    agree: false,
  });

  const [passwordError, setPasswordError] = useState("");
  const [formError, setFormError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;

    if (name === "password") {
      // ✅ Password validation regex
      const passwordRegex =
        /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*]).{8,}$/;
      if (!passwordRegex.test(value)) {
        setPasswordError(
          "Password must be at least 8 characters, include one uppercase letter, one number, and one special character."
        );
      } else {
        setPasswordError("");
      }
    }

    setForm({
      ...form,
      [name]: type === "checkbox" ? checked : value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (passwordError) {
      setFormError(passwordError);
      setSuccessMessage("");
      return;
    }

    if (form.password !== form.confirmPassword) {
      setFormError("Passwords do not match!");
      setSuccessMessage("");
      return;
    }

    if (!form.agree) {
      setFormError("Please accept the terms of service.");
      setSuccessMessage("");
      return;
    }

    // ✅ Save user data in localStorage
    localStorage.setItem(
      "user",
      JSON.stringify({
        name: form.name,
        email: form.email,
        password: form.password,
        department: form.department,
        year: form.year,
      })
    );

    setFormError(""); 
    setSuccessMessage("✅ Successfully Registered!");

    console.log("Form Submitted:", form);

    // Redirect after 2 sec
    setTimeout(() => {
      router.push("/login");
    }, 2000);
  };

  return (
    <div
      className="relative min-h-screen flex items-center justify-center bg-cover bg-center"
      style={{ backgroundImage: "url('/5.jpg')" }}
    >
      <div className="absolute inset-0 bg-gradient-to-r from-purple-600/60 to-teal-500/60"></div>

      <div className="relative bg-white rounded-2xl shadow-lg p-8 w-full max-w-md">
        <h2 className="text-2xl font-bold text-center mb-4">CREATE ACCOUNT</h2>

        {/* Error Message */}
        {formError && (
          <div className="mb-4 p-3 rounded-lg bg-red-100 border border-red-400 text-red-700 text-sm text-center">
            {formError}
          </div>
        )}

        {/* Success Message */}
        {successMessage && (
          <div className="mb-4 p-3 rounded-lg bg-green-100 border border-green-400 text-green-700 text-sm text-center">
            {successMessage}
          </div>
        )}

        <form className="space-y-4" onSubmit={handleSubmit}>
          <input
            type="text"
            name="name"
            placeholder="Full Name"
            value={form.name}
            onChange={handleChange}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-400 outline-none"
            required
          />

          <input
            type="email"
            name="email"
            placeholder="Your Email"
            value={form.email}
            onChange={handleChange}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-400 outline-none"
            required
          />

          <input
            type="password"
            name="password"
            placeholder="Password"
            value={form.password}
            onChange={handleChange}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-400 outline-none"
            required
          />
          {passwordError && (
            <p className="text-red-500 text-sm">{passwordError}</p>
          )}

          <input
            type="password"
            name="confirmPassword"
            placeholder="Repeat your password"
            value={form.confirmPassword}
            onChange={handleChange}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-400 outline-none"
            required
          />

          <select
            name="department"
            value={form.department}
            onChange={handleChange}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-400 outline-none"
          >
            <option value="AI">AI</option>
          </select>

          <select
            name="year"
            value={form.year}
            onChange={handleChange}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-400 outline-none"
          >
            <option value="I">I Year</option>
            <option value="II">II Year</option>
            <option value="III">III Year</option>
          </select>

          <label className="flex items-center text-sm">
            <input
              type="checkbox"
              name="agree"
              checked={form.agree}
              onChange={handleChange}
              className="mr-2"
            />
            I agree all statements in{" "}
            <a href="#" className="text-purple-500 ml-1 underline">
              Terms of service
            </a>
          </label>

          <button
            type="submit"
            className="w-full py-2 text-white font-semibold rounded-lg bg-gradient-to-r from-purple-500 to-teal-400 hover:opacity-90 transition"
          >
            SIGN UP
          </button>
        </form>

        <p className="text-sm text-center mt-4">
          Have already an account?{" "}
          <a href="/login" className="text-purple-500 font-medium underline">
            Login here
          </a>
        </p>
      </div>
    </div>
  );
}

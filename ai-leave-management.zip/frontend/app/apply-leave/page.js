"use client";
import { useState, useEffect } from "react";

export default function ApplyLeavePage() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    reason: "",
    fromDate: "",
    toDate: "",
    status: "Pending",
  });

  const [successMessage, setSuccessMessage] = useState("");

  useEffect(() => {
    // Get logged in user from localStorage
    const user = JSON.parse(localStorage.getItem("user"));
    if (user) {
      setForm((prev) => ({
        ...prev,
        name: user.name,
        email: user.email,
      }));
    }
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({
      ...form,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Save leave to localStorage
    const savedLeaves = JSON.parse(localStorage.getItem("leaves") || "[]");
    savedLeaves.push(form);
    localStorage.setItem("leaves", JSON.stringify(savedLeaves));

    // ✅ Success message set
    setSuccessMessage("✅ Leave Submitted Successfully!");

    // Reset form except name/email
    setForm((prev) => ({
      ...prev,
      reason: "",
      fromDate: "",
      toDate: "",
    }));

    // ✅ Redirect to dashboard after 1.5 sec
    setTimeout(() => {
      window.location.href = "/dashboard";
    }, 1500);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-purple-500 to-teal-400 p-6">
      <div className="bg-white rounded-2xl shadow-lg p-8 w-full max-w-md">
        <h2 className="text-2xl font-bold text-center mb-6">Apply for Leave</h2>

        {/* ✅ Success Message */}
        {successMessage && (
          <div className="mb-4 p-3 rounded-lg bg-green-100 border border-green-400 text-green-700 text-sm text-center">
            {successMessage}
          </div>
        )}

        <form className="space-y-4" onSubmit={handleSubmit}>
          {/* Name (auto-filled) */}
          <input
            type="text"
            name="name"
            value={form.name}
            readOnly
            className="w-full px-4 py-2 border rounded-lg bg-gray-100"
          />

          {/* Email (auto-filled) */}
          <input
            type="email"
            name="email"
            value={form.email}
            readOnly
            className="w-full px-4 py-2 border rounded-lg bg-gray-100"
          />

          {/* Reason */}
          <input
            type="text"
            name="reason"
            placeholder="Reason for Leave"
            value={form.reason}
            onChange={handleChange}
            className="w-full px-4 py-2 border rounded-lg"
            required
          />

          {/* From Date */}
          <input
            type="date"
            name="fromDate"
            value={form.fromDate}
            onChange={handleChange}
            className="w-full px-4 py-2 border rounded-lg"
            required
          />

          {/* To Date */}
          <input
            type="date"
            name="toDate"
            value={form.toDate}
            onChange={handleChange}
            className="w-full px-4 py-2 border rounded-lg"
            required
          />

          {/* Submit */}
          <button
            type="submit"
            className="w-full py-2 text-white font-semibold rounded-lg bg-gradient-to-r from-purple-500 to-teal-400 hover:opacity-90 transition"
          >
            Submit Leave
          </button>
        </form>
      </div>
    </div>
  );
}

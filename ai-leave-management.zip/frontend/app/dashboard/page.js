'use client';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';

export default function StudentDashboard() {
  const router = useRouter();
  const [studentName, setStudentName] = useState('Student');

  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem('user'));
    if (storedUser && storedUser.name) {
      setStudentName(storedUser.name);
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('user'); // ✅ Clear user data
    router.push('/login'); // ✅ Redirect to login page
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-purple-500 to-teal-400 p-6">
      <div className="w-full max-w-6xl bg-white rounded-2xl shadow-2xl p-10 relative">

        {/* 🔹 Logout Button */}
        <button
          onClick={handleLogout}
          className="absolute top-6 right-6 bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg shadow"
        >
          Logout
        </button>

        {/* 🔹 Welcome */}
        <h1 className="text-4xl font-bold text-center text-purple-700 mb-10">
          Welcome, {studentName}
        </h1>

        {/* 🔹 Dashboard Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          
          {/* Apply Leave */}
          <div
            className="bg-blue-100 p-8 rounded-xl shadow hover:shadow-2xl cursor-pointer transition"
            onClick={() => router.push('/apply-leave')}
          >
            <h2 className="text-2xl font-bold mb-2 text-blue-800">Apply for Leave</h2>
            <p className="text-gray-700">Submit a new leave application.</p>
          </div>

          {/* Leave History */}
          <div
            className="bg-green-100 p-8 rounded-xl shadow hover:shadow-2xl cursor-pointer transition"
            onClick={() => router.push('/leave-status')}
          >
            <h2 className="text-2xl font-bold mb-2 text-green-800">Leave History</h2>
            <p className="text-gray-700">Check status of past leave applications.</p>
          </div>

          {/* Profile */}
          <div
            className="bg-yellow-100 p-8 rounded-xl shadow hover:shadow-2xl cursor-pointer transition"
            onClick={() => router.push('/profile')}
          >
            <h2 className="text-2xl font-bold mb-2 text-yellow-800">My Profile</h2>
            <p className="text-gray-700">View and update your profile details.</p>
          </div>

        </div>
      </div>
    </div>
  );
}

"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function ForgotPasswordPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [messageType, setMessageType] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    const savedUser = JSON.parse(localStorage.getItem("user"));

    if (!savedUser) {
      setMessage("❌ No user found. Please register first!");
      setMessageType("error");
      return;
    }

    // ✅ Email check
    if (email.trim().toLowerCase() !== savedUser.email.toLowerCase()) {
      setMessage("❌ Email does not match our records!");
      setMessageType("error");
      return;
    }

    // ✅ Reset password process (dummy)
    setMessage("✅ Password reset link sent to your email!");
    setMessageType("success");

    setTimeout(() => {
      router.push("/"); // Redirect to login page after success
    }, 2000);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-teal-400 to-purple-500 p-6">
      <div className="bg-white rounded-2xl shadow-lg p-8 w-full max-w-md">
        <h2 className="text-2xl font-bold text-center mb-6">Forgot Password</h2>

        {message && (
          <div
            className={`mb-4 p-3 rounded-lg text-sm text-center ${
              messageType === "error"
                ? "bg-red-100 border border-red-400 text-red-700"
                : "bg-green-100 border border-green-400 text-green-700"
            }`}
          >
            {message}
          </div>
        )}

        <form className="space-y-4" onSubmit={handleSubmit}>
          <input
            type="email"
            name="email"
            placeholder="Enter your registered email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-400 outline-none"
            required
          />

          <button
            type="submit"
            className="w-full py-2 text-white font-semibold rounded-lg bg-gradient-to-r from-purple-500 to-teal-400 hover:opacity-90 transition"
          >
            Send Reset Link
          </button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-sm">
            Remembered your password?{" "}
            <button
              onClick={() => router.push("/login")}
              className="text-purple-600 font-semibold hover:underline"
            >
              Back to Login
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
